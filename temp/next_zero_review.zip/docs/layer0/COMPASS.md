1. DETECT

Identify the strongest coherence signal.

Act.

---

2. EXPRESS

Express it fully.

---

3. ALLOW

Allow the outcome.

---

4. MAINTAIN

Remain coherent.

---

5. CALIBRATE

Calibrate beliefs.
