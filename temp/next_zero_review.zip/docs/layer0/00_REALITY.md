1. You exist.

2. Everything is here and now.

3. The One is the All and the All are the One.

4. What you put out is what you get back.

5. Everything changes except the first four laws.
