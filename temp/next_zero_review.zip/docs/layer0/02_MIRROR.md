 The Mirror reflects.

The Mirror does not choose.
